<?php
// Configuración de la conexión a la base de datos
$host = 'localhost';
$dbname = 'datos';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error al conectar a la base de datos: " . $e->getMessage());
}

// Obtener los datos de la tabla dia junto con los datos de usuario
$sql = "
    SELECT u.nombre, u.apellido, u.dni, d.ingreso, d.salida, d.fecha, d.dia
    FROM dia d
    JOIN usuario u ON d.id_usuario = u.id_usuario
    ORDER BY d.fecha DESC, d.salida DESC;
";

$stmt = $pdo->prepare($sql);
$stmt->execute();
$registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Función para calcular la diferencia en horas y minutos
function calcularTiempoTotal($ingreso, $salida) {
    $ingresoTime = new DateTime($ingreso);
    $salidaTime = new DateTime($salida);
    $intervalo = $ingresoTime->diff($salidaTime);
    
    // Regresar la diferencia en horas y minutos
    return $intervalo->format('%H horas %I minutos');
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Horarios de Entrada y Salida</title>
    <link rel="stylesheet" href="login.css"> <!-- Si usas CSS externo -->

</head>
<body>
    <h1>Horarios de Entrada y Salida</h1>
    <nav class="bg-red-700">
        <a href="index.php" class="">SALIR</a>
    </nav>
    <table border="1" cellpadding="10">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>DNI</th>
                <th>Ingreso</th>
                <th>Salida</th>
                <th>Fecha</th>
                <th>Día</th>
                <th>Tiempo Total</th> <!-- Nueva columna para el tiempo total -->
            </tr>
        </thead>
        <tbody>
            <?php if (count($registros) > 0): ?>
                <?php foreach ($registros as $registro): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($registro['nombre']); ?></td>
                        <td><?php echo htmlspecialchars($registro['apellido']); ?></td>
                        <td><?php echo htmlspecialchars($registro['dni']); ?></td>
                        <td><?php echo htmlspecialchars($registro['ingreso']); ?></td>
                        <td><?php echo htmlspecialchars($registro['salida']); ?></td>
                        <td><?php echo htmlspecialchars($registro['fecha']); ?></td>
                        <td><?php echo htmlspecialchars($registro['dia']); ?></td>
                        <td>
                            <?php 
                                // Mostrar el tiempo total calculado
                                echo calcularTiempoTotal($registro['ingreso'], $registro['salida']);
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8">No se encontraron registros</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>
