<?php
session_start();
// Configuración de la conexión a la base de datos
$host = 'localhost';
$dbname = 'datos';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error al conectar a la base de datos: " . $e->getMessage());
}

if (isset($_POST['tabla'])) {
    $tabla = $_POST['tabla'];

    switch ($tabla) {
        case 'usuario':
            // Verificar si el DNI ya existe en la base de datos
            $sql_check = "SELECT id_usuario, email FROM usuario WHERE dni = :dni";
            $stmt_check = $pdo->prepare($sql_check);
            $stmt_check->execute([ ':dni' => $_POST['dni'] ]);

            if ($stmt_check->rowCount() > 0) {
                // Si ya existe, mostrar mensaje de error y no continuar con la inserción
                echo "El DNI ya está registrado en el sistema. Por favor, ingrese un DNI diferente.";
                exit; // Terminar el script si el DNI ya existe
            }

            // Si el DNI no existe, insertar el nuevo usuario
            $sql_insert = "INSERT INTO usuario (nombre, apellido, rol, email, dni, fecha_nacimiento) 
                           VALUES (:nombre, :apellido, :rol, :email, :dni, :fecha_nacimiento)";
            $stmt_insert = $pdo->prepare($sql_insert);
            $stmt_insert->execute([
                ':nombre' => $_POST['nombre'],
                ':apellido' => $_POST['apellido'],
                ':rol' => $_POST['rol'],
                ':email' => $_POST['email'],
                ':dni' => $_POST['dni'],
                ':fecha_nacimiento' => $_POST['fecha_nacimiento']
            ]);

            // Obtener el id y el email del usuario recién insertado
            $id_usuario = $pdo->lastInsertId();
            $dni = $_POST['dni'];

            // Iniciar sesión automáticamente con el correo del usuario
            $_SESSION['id_usuario'] = $id_usuario;
            $_SESSION['dni'] = $dni; // Usamos el correo como identificador

            // Redirigir a la página de curso (o cualquier otra página donde desees llevar al usuario)
            header("Location: curso_form.php");
            exit;

        case 'curso':
            // Verificar si todas las claves están presentes en $_POST, si no asignar NULL
            $nivel = isset($_POST['nivel']) ? $_POST['nivel'] : NULL;
            $divicion = isset($_POST['divicion']) ? $_POST['divicion'] : NULL;
            $turno = isset($_POST['turno']) ? $_POST['turno'] : NULL;
            $modalidad = isset($_POST['modalidad']) ? $_POST['modalidad'] : NULL;

            // Insertar curso
            $sql = "INSERT INTO curso (nivel, divicion, turno, modalidad) 
                    VALUES (:nivel, :divicion, :turno, :modalidad)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nivel' => $nivel,
                ':divicion' => $divicion,
                ':turno' => $turno,
                ':modalidad' => $modalidad
            ]);
            // Redirigir a la página de día
            header("Location: dia_form.php");
            exit;

            // Verificar si ya existe un registro para este usuario en el día seleccionado




            // Insertar el registro de ingreso y salida en la tabla 'dia'
         

            // Redirigir a la página de reseña

        case 'reseña':
            // Insertar reseña
            $sql = "INSERT INTO resena (calificacion, donacion, opinion, resena) 
                    VALUES (:calificacion, :donacion, :opinion, :resena)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':calificacion' => $_POST['calificacion'],
                ':donacion' => $_POST['donacion'],
                ':opinion' => $_POST['opinion'],
                ':resena' => $_POST['resena']
            ]);
            // Redirigir al índice
            header("Location: index.php"); 
            exit;

        default:
            die("Tabla no reconocida.");
    }
} else {
    echo "No se recibió la tabla a registro_be.";
}
?>
