<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css"> 
    <link rel="stylesheet" href="/FORMULARIOO/src/output.css">
</head>
<body>
    <form method="POST" action="salida_be.php">
        <div class="formulario" id="login"><br><br>
            <h1>LOGIN</h1><br><br>
            <div class="input">
                <section class="input">
                    <input name="dni" type="text" maxlength="8" placeholder="DNI" required>
                    <br><br><br>
                    <input type="submit" value="REGISTRAR SALIDA" id="enviar">
                </section>
            </div>
        </div>
    </form>
</body>
</html>
