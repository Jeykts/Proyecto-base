<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>formulario</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<header>
    <nav class="menu">
        <h1>EXPO<span id="ere"> CHACA</span></h1>
        <ul>
            <li><a href="index.php">USUARIO</a></li>
            <li><a href="curso_form.php">CURSO</a></li>
            <li><a href="dia_form.php">DIA</a></li>
            <li><a href="resena_form.php">RESEÑAS</a></li>
            <li><a href="login.php">SALIDA</a></li>
            <li><a href="infousu.php">INFO</a></li>
        </ul>
        <ul>
            <li><a href="index5.php" id="por">PROYECTOS</a></li>
        </ul>
    </nav>
</header>
<br><br><br>
<form method="POST" action="registro_be.php">
        <div class="formulario" id="reseña"><br><br>
            <h1>SECCIÓN DE RESEÑA</h1><br><br>
            <div class="input">
                <section class="input">
                    <input name="tabla" type="hidden" value="reseña">
                    <input name="calificacion" type="number" min="1" max="5" placeholder="Calificación (1-5)" required>
                    <input name="donacion" type="number" step="0.01" placeholder="Donación"><br><br>
                    <textarea name="opinion" placeholder="Opinión" rows="3"></textarea><br><br>
                    <textarea name="reseña" placeholder="Reseña" rows="3"></textarea><br><br><br>
                    <input type="submit" value="ENVIAR" id="enviar">
                </section>
            </div>
        </div>
    </form>
<br><br><br><br>
    <footer id="pie" class="pie-pagina">
        <div class="grupo-1">
            <div class="box">
                <h2>CONTACTO</h2>
                <P class="fa fa-envelope"><span id="m">tecnicachacabuco1@gmail.com</span></P>
                <br>
                <P class="fa fa-envelope"><span id="m">chacabucotecnica6@gmail.com</span></P>
                <br>
                <P class="fa fa-envelope"><span id="m">tecnic6chacabuco@gmail.com</span></P>
            </div>
            <div class="box">
                <h2>SOBRE NOSOTROS</h2>
                <P class="fa fa-map-marker"><span id="m">AV.rivadavia 1567</span></P>
                <br>
                <P class="fa fa-map-marker"><span id="m">Juan B.Justo 4567</span></P>
                <br>
                <P class="fa fa-phone"><span id="m">1164002623</span></P>
            </div>
            <div class="box">
                <h2>SOBRE NOSOTROS</h2>
                <P class="fa fa-map-marker"><span id="m">AV.rivadavia 1567</span></P>
                <br>
                <P class="fa fa-map-marker"><span id="m">Juan B.Justo 4567</span></P>
                <br>
                <P class="fa fa-phone"><span id="m">1164002623</span></P>
            </div>
            <div class="box">
                <h2>REDES SOCIALES</h2>
                <div class="red">
                    <a href="https://www.facebook.com/p/EEST-N6-Chacabuco-Mor%C3%B3n-100069829001357/" class="fa fa-facebook"></a>
                    <a href="https://www.instagram.com/tecnica6moron_oficial/?hl=es" class="fa fa-instagram"></a>
                    <a href="https://www.youtube.com/watch?v=lFRe9D_1FYc" class="fa fa-youtube"></a>
                    <a href="https://x.com/EscueladeEduca3" class="fa fa-twitter"></a>
                </div>
            </div>
        </div>
        <div class="grupo-2">
            <small>2024-CHACABUCO-TODOS LOS DERECHOS RESERVADOS</small>
        </div>

        

        <script>
            function showSection(id){
                document.querySelectorAll('.section').forEach(section => {
                    section.classList.remove('active');
                });
                document.getEelementById(id).classList.add('active');
            }
        </script>
    </footer>

</body>
</html>