<?php
// Configuración de la conexión a la base de datos
$host = 'localhost';
$dbname = 'datos';
$username = 'root';
$password = '';

// Configura la zona horaria de Argentina
date_default_timezone_set('America/Argentina/Buenos_Aires');

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error al conectar a la base de datos: " . $e->getMessage());
}

// Verificar si el DNI fue enviado por POST
if (isset($_POST['dni'])) {
    $dni = $_POST['dni'];

    // Obtener la hora actual en la zona horaria de Argentina
    $hora_salida = date('H:i:s');
    $fecha = date('Y-m-d');
    $dia = date('l');  // Día de la semana en inglés (puedes cambiarlo a español si lo deseas)

    // Verificar si el usuario existe en la base de datos
    $sql_validar = "SELECT id_usuario FROM usuario WHERE dni = :dni";
    $stmt_validar = $pdo->prepare($sql_validar);
    $stmt_validar->execute([':dni' => $dni]);

    if ($stmt_validar->rowCount() > 0) {
        // Obtener el id_usuario
        $usuario = $stmt_validar->fetch(PDO::FETCH_ASSOC);
        $id_usuario = $usuario['id_usuario'];

        // Actualizar la hora de salida sin importar si ya existe un registro
        $sql_update = "UPDATE dia SET salida = :salida WHERE id_usuario = :id_usuario AND fecha = :fecha";
        $stmt_update = $pdo->prepare($sql_update);
        $stmt_update->execute([
            ':salida' => $hora_salida,
            ':id_usuario' => $id_usuario,
            ':fecha' => $fecha
        ]);

        echo "Hora de salida registrada correctamente.";
        // Redirigir a la página principal (o la página que necesites después de registrar la salida)
        header("Location: index.php");
        exit;

    } else {
        echo "El DNI ingresado no está registrado.";
    }
} else {
    echo "No se recibió ningún DNI.";
}
?>
