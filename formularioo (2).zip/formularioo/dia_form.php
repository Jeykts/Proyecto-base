<?php 
session_start();

// Verificamos si el DNI está presente en la sesión
if (isset($_SESSION['dni'])) {
    $dni = $_SESSION['dni']; // Asignamos el DNI desde la sesión
} else {
    // Si no hay sesión o el DNI no está en la sesión, redirigimos al login
    echo "No estás logueado. Por favor, inicia sesión.";
    header("Location: login.php"); // Redirige al login
    exit;
}

// Configuración de la conexión a la base de datos
$host = 'localhost';
$dbname = 'datos';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error al conectar a la base de datos: " . $e->getMessage());
}

// Verificar si el usuario existe en la base de datos
$sql_validar = "SELECT id_usuario FROM usuario WHERE dni = :dni";
$stmt_validar = $pdo->prepare($sql_validar);
$stmt_validar->execute([':dni' => $dni]);

if ($stmt_validar->rowCount() > 0) {
    // Obtener el id_usuario
    $usuario = $stmt_validar->fetch(PDO::FETCH_ASSOC);
    $id_usuario = $usuario['id_usuario'];

    // Si el formulario ha sido enviado, registrar el ingreso
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $ingreso = $_POST['ingreso']; // Hora de ingreso
        $fecha = $_POST['fecha']; // Fecha
        $dia = date('l');  // Día de la semana

        // Insertar el registro de ingreso en la tabla dia con la salida como un valor temporal
        $sql_insert = "INSERT INTO dia (ingreso, fecha, dia, id_usuario, salida) 
                       VALUES (:ingreso, :fecha, :dia, :id_usuario, '00:00:00')";
        $stmt_insert = $pdo->prepare($sql_insert);
        $stmt_insert->execute([
            ':ingreso' => $ingreso,
            ':fecha' => $fecha,
            ':dia' => $dia,
            ':id_usuario' => $id_usuario
        ]);

        echo "Ingreso registrado correctamente.";
        // Redirigir después de registrar el ingreso
        header("Location: index.php");
        exit;
    }
} else {
    echo "El DNI ingresado no está registrado.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario Ingreso</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<header>
    <nav class="menu">
        <h1>EXPO<span id="ere"> CHACA</span></h1>
        <ul>
            <li><a href="index.php">USUARIO</a></li>
            <li><a href="curso_form.php">CURSO</a></li>
            <li><a href="dia_form.php">DIA</a></li>
            <li><a href="resena_form.php">RESEÑAS</a></li>
            <li><a href="login.php">SALIDA</a></li>
            <li><a href="infousu.php">INFO</a></li>
        </ul>
        <ul>
            <li><a href="index5.php" id="por">PROYECTOS</a></li>
        </ul>
    </nav>
</header>

<br><br><br>
<form method="POST">
    <div class="formulario" id="dia"><br><br>
        <h1>SECCIÓN DE DÍA</h1><br><br>
        <div class="input">
            <section class="input">
                <input name="tabla" type="hidden" value="dia">
                <input name="ingreso" type="time" placeholder="Hora de Ingreso" required><br><br>
                <input name="fecha" type="date" placeholder="Fecha" required><br>
                <input type="submit" value="ENVIAR" id="enviar">
            </section>
        </div>
    </div>
</form>

<br><br><br><br>

<footer id="pie" class="pie-pagina">
    <div class="grupo-1">
        <div class="box">
            <h2>CONTACTO</h2>
            <P class="fa fa-envelope"><span id="m">tecnicachacabuco1@gmail.com</span></P>
            <br>
            <P class="fa fa-envelope"><span id="m">chacabucotecnica6@gmail.com</span></P>
            <br>
            <P class="fa fa-envelope"><span id="m">tecnic6chacabuco@gmail.com</span></P>
        </div>
    </div>
    <div class="grupo-2">
        <small>2024-CHACABUCO-TODOS LOS DERECHOS RESERVADOS</small>
    </div>
</footer>

</body>
</html>
