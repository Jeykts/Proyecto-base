<?php

    $conexion =  mysqli_connect("localhost", "root","","datos");

   /* if($conexion){
        echo "Conectado";
    }else{
        echo "Error Base de Datos";
    }
*/

?>